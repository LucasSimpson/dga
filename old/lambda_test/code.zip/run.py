

def handler(*args, **kwargs):
	print(args)
	print(kwargs)

	val = kwargs.get('number', 0)

	return val**2 + 2*val - 10